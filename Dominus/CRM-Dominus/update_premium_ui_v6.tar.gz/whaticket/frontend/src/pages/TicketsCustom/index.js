import React, { useState, useCallback, useContext, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import Paper from "@material-ui/core/Paper";
import Hidden from "@material-ui/core/Hidden";
import { makeStyles } from "@material-ui/core/styles";
import TicketsManager from "../../components/TicketsManagerTabs";
import Ticket from "../../components/Ticket";

import { QueueSelectedProvider } from "../../context/QueuesSelected/QueuesSelectedContext";
import { i18n } from "../../translate/i18n";
import { AuthContext } from "../../context/Auth/AuthContext";
import { TicketsContext } from "../../context/Tickets/TicketsContext";
import api from "../../services/api";
import { useMediaQuery, useTheme } from "@material-ui/core";

const defaultTicketsManagerWidth = 550;
const minTicketsManagerWidth = 404;
const maxTicketsManagerWidth = 700;

const useStyles = makeStyles((theme) => ({
	chatContainer: {
		display: "flex",
		height: "100%",
		width: "100%",
		flex: 1,
		padding: 0,
		overflowY: "hidden",
	},
	chatPapper: {
		display: "flex",
		width: "100%",
		height: "100%",
		borderRadius: 0,
		overflow: "hidden",
	},
	contactsWrapper: {
		display: "flex",
		width: "360px",
		minWidth: "360px",
		maxWidth: "360px",
		height: "100%",
		flexDirection: "column",
		overflow: "hidden",
		position: "relative",
		backgroundColor: "#FFFFFF",
		borderRight: "1px solid #E5E7EB",
		transition: "width 0.3s ease",
		[theme.breakpoints.down("xs")]: {
			width: "100%",
			minWidth: "100%",
			maxWidth: "100%",
			borderRight: "none",
		},
	},
	messagesWrapper: {
		display: "flex",
		height: "100%",
		flexDirection: "column",
		flexGrow: 1,
		backgroundColor: "#FFFFFF",
		[theme.breakpoints.down("sm")]: {
			width: "100%",
			flexGrow: 1,
		},
	},
	hiddenMobile: {
		[theme.breakpoints.down("xs")]: {
			display: "none",
		},
	},
	welcomeMsg: {
		background:
			theme.mode === "light"
				? "linear-gradient(135deg, #ffffff 0%, #f4f8ff 100%)"
				: "linear-gradient(135deg, rgba(30,41,59,0.95) 0%, rgba(15,23,42,0.95) 100%)",
		display: "flex",
		justifyContent: "center",
		alignItems: "center",
		height: "100%",
		textAlign: "center",
		borderRadius: 16,
		border: `1px solid ${theme.palette.divider}`,
		margin: theme.spacing(1),
		boxShadow:
			theme.mode === "light"
				? "0 10px 22px rgba(15, 23, 42, 0.08)"
				: "0 10px 22px rgba(0, 0, 0, 0.35)",
		color: theme.palette.text.primary,
	},
	welcomeInner: {
		maxWidth: 420,
		padding: theme.spacing(2),
	},
	welcomeTitle: {
		fontSize: "1.15rem",
		fontWeight: 700,
		marginTop: theme.spacing(1),
	},
	welcomeText: {
		marginTop: theme.spacing(0.7),
		fontSize: "0.86rem",
		lineHeight: 1.45,
		color: theme.palette.text.secondary,
	},
	logo: {
		logo: theme.logo,
		content: "url(" + (theme.mode === "light" ? theme.calculatedLogoLight() : theme.calculatedLogoDark()) + ")",
		opacity: 0.92,
		filter: theme.mode === "light" ? "none" : "brightness(1.12)",
	},
}));

const TicketsCustom = () => {
	const theme = useTheme();
	const isMobile = useMediaQuery(theme.breakpoints.down("xs"));
	const { user } = useContext(AuthContext);

	const classes = useStyles();

	const { ticketId } = useParams();
	const { currentTicket } = useContext(TicketsContext);
	const [selectedChat, setSelectedChat] = useState(null);

	useEffect(() => {
		if (currentTicket.uuid) {
			setSelectedChat(currentTicket.uuid);
		} else {
			setSelectedChat(null);
		}
	}, [currentTicket]);

	useEffect(() => {
		if (ticketId) {
			setSelectedChat(ticketId);
		}
	}, [ticketId]);

	return (
		<QueueSelectedProvider>
			<div className={classes.chatContainer}>
				<div className={classes.chatPapper}>
					{/* LISTA DE CHATS - No Desktop sempre visível. No Mobile só se não houver chat selecionado. */}
					<div className={`${classes.contactsWrapper} ${isMobile && selectedChat ? classes.hiddenMobile : ""}`}>
						<TicketsManager />
					</div>

					{/* ÁREA DA CONVERSA - No Desktop sempre visível. No Mobile só se houver chat selecionado. */}
					<div className={`${classes.messagesWrapper} ${isMobile && !selectedChat ? classes.hiddenMobile : ""}`}>
						{selectedChat ? (
							<Ticket />
						) : (
							<div className={classes.welcomeMsg}>
								<div className={classes.welcomeInner}>
									<center>
										<img className={classes.logo} width="48%" alt="" />
									</center>
									<div className={classes.welcomeTitle}>Central de Atendimentos</div>
									<div className={classes.welcomeText}>{i18n.t("chat.noTicketMessage")}</div>
								</div>
							</div>
						)}
					</div>
				</div>
			</div>
		</QueueSelectedProvider>
	);
};

export default TicketsCustom;
