import React from "react";
import { i18n } from "../../translate/i18n";
import { Avatar, CardHeader, Grid, IconButton, Tooltip, Typography, useTheme } from "@material-ui/core";
import SearchIcon from "@material-ui/icons/Search";
import CloseIcon from "@material-ui/icons/Close";

const TicketInfo = ({ contact, ticket, onClick, onToggleSearch, isSearching }) => {

	const renderCardReader = () => {
		return (
			<div style={{ display: 'flex', alignItems: 'center', padding: '8px 16px' }}>
				<Avatar 
					src={contact?.urlPicture} 
					alt="contact_image" 
					style={{ width: 40, height: 40, marginRight: 12, border: '2px solid #fff', boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }} 
				/>
				<div style={{ flex: 1, overflow: 'hidden' }}>
					<Typography variant="subtitle1" style={{ fontWeight: 700, lineHeight: 1.2, color: theme.mode === 'light' ? '#0f172a' : '#f8fafc', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
						{contact?.name || '(sem contato)'}
					</Typography>
					<Typography variant="caption" style={{ color: '#64748b', fontWeight: 500 }}>
						{ticket.user ? `${i18n.t("messagesList.header.assignedTo")} ${ticket.user.name}` : 'Aguardando atendimento'}
					</Typography>
				</div>
				<Tooltip title={isSearching ? "Fechar busca" : "Buscar na conversa"}>
					<IconButton
						size="small"
						onClick={(e) => {
							e.stopPropagation();
							if (onToggleSearch) onToggleSearch();
						}}
						style={{ marginLeft: 8, color: '#64748b' }}
					>
						{isSearching ? <CloseIcon fontSize="small" /> : <SearchIcon fontSize="small" />}
					</IconButton>
				</Tooltip>
			</div>
		);
	}

	return (
		<div style={{ flex: 1 }}>
			{renderCardReader()}
		</div>
	);
};

export default TicketInfo;
