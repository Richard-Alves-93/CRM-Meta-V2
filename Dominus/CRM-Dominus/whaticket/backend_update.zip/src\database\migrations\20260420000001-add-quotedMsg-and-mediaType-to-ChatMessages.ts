import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: async (queryInterface: QueryInterface) => {
    await queryInterface.addColumn("ChatMessages", "quotedMsgId", {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: { model: "ChatMessages", key: "id" },
      onUpdate: "CASCADE",
      onDelete: "SET NULL"
    });
    await queryInterface.addColumn("ChatMessages", "mediaType", {
      type: DataTypes.STRING,
      allowNull: true
    });
  },

  down: async (queryInterface: QueryInterface) => {
    await queryInterface.removeColumn("ChatMessages", "quotedMsgId");
    await queryInterface.removeColumn("ChatMessages", "mediaType");
  }
};
