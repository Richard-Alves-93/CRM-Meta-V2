import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: (queryInterface: QueryInterface) => {
    return Promise.all([
      queryInterface.addColumn("Companies", "paymentGateway", {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: "mercadopago"
      }),
      queryInterface.addColumn("Companies", "infinitePayToken", {
        type: DataTypes.STRING,
        allowNull: true
      }),
      queryInterface.addColumn("Companies", "infinitePayHandle", {
        type: DataTypes.STRING,
        allowNull: true
      })
    ]);
  },

  down: (queryInterface: QueryInterface) => {
    return Promise.all([
      queryInterface.removeColumn("Companies", "paymentGateway"),
      queryInterface.removeColumn("Companies", "infinitePayToken"),
      queryInterface.removeColumn("Companies", "infinitePayHandle")
    ]);
  }
};
