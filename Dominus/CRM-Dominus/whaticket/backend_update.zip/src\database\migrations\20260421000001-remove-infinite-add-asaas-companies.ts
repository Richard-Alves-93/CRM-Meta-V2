import { QueryInterface, DataTypes } from "sequelize";

module.exports = {
  up: (queryInterface: QueryInterface) => {
    return Promise.all([
      queryInterface.addColumn("Companies", "asaasToken", {
        type: DataTypes.STRING,
        allowNull: true
      }),
      queryInterface.removeColumn("Companies", "infinitePayToken"),
      queryInterface.removeColumn("Companies", "infinitePayHandle")
    ]);
  },

  down: (queryInterface: QueryInterface) => {
    return Promise.all([
      queryInterface.removeColumn("Companies", "asaasToken"),
      queryInterface.addColumn("Companies", "infinitePayToken", {
        type: DataTypes.STRING,
        allowNull: true
      }),
      queryInterface.addColumn("Companies", "infinitePayHandle", {
        type: DataTypes.STRING,
        allowNull: true
      })
    ]);
  }
};
